import os, uuid, subprocess, shutil
from pathlib import Path
from flask import Flask, request, render_template, send_from_directory, flash, redirect, url_for
from werkzeug.utils import secure_filename

BASE = Path(__file__).parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-deploying")
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024  # 1 GB upload limit
ALLOWED = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}

def run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout or "Processing failed")[-1800:])
    return result.stdout

def get_duration(path):
    out = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
               "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    return max(0, float(out.strip()))

def make_clips(source, job_dir, clip_seconds=30):
    duration = get_duration(source)
    if duration < 2:
        raise ValueError("This video is too short.")
    count = min(10, int((duration + clip_seconds - 1) // clip_seconds))
    made = []
    for i in range(count):
        start = i * clip_seconds
        length = min(clip_seconds, duration - start)
        dest = job_dir / f"clip_{i+1:02d}.mp4"
        run(["ffmpeg", "-y", "-ss", str(start), "-i", str(source), "-t", str(length),
             "-vf", "scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280",
             "-c:v", "libx264", "-preset", "veryfast", "-crf", "25",
             "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(dest)])
        made.append(dest.name)
    return made

@app.route("/", methods=["GET", "POST"])
def home():
    clips = []
    if request.method == "POST":
        job_id = uuid.uuid4().hex[:12]
        job_dir = OUTPUTS / job_id
        job_dir.mkdir(parents=True)
        source = None
        uploaded = request.files.get("video")
        video_url = request.form.get("video_url", "").strip()
        try:
            if uploaded and uploaded.filename:
                ext = Path(secure_filename(uploaded.filename)).suffix.lower()
                if ext not in ALLOWED:
                    raise ValueError("Please upload an MP4, MOV, MKV, WEBM or M4V video.")
                source = UPLOADS / f"{job_id}{ext}"
                uploaded.save(source)
            elif video_url:
                # yt-dlp supports many public URLs, but availability depends on the platform.
                source = UPLOADS / f"{job_id}.mp4"
                run(["yt-dlp", "--no-playlist", "-f", "bv*[height<=1080]+ba/b[height<=1080]",
                     "--merge-output-format", "mp4", "-o", str(source), video_url])
            else:
                raise ValueError("Paste a video link or choose a video file.")
            clips = make_clips(source, job_dir)
            return render_template("index.html", clips=[(job_id, c) for c in clips],
                                   message=f"Created {len(clips)} clips. These are evenly spaced segments, not AI-selected highlights.")
        except Exception as e:
            shutil.rmtree(job_dir, ignore_errors=True)
            flash(f"Could not process this video: {e}")
            return redirect(url_for("home"))
        finally:
            if source and source.exists():
                source.unlink(missing_ok=True)
    return render_template("index.html", clips=clips)

@app.route("/clips/<job_id>/<path:filename>")
def download_clip(job_id, filename):
    folder = OUTPUTS / job_id
    if not folder.exists():
        return "Clip not found", 404
    return send_from_directory(folder, filename, as_attachment=True)

@app.route("/health")
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
