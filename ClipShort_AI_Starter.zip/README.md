# ClipShort AI — starter MVP

A beginner-friendly Flask web app with a premium dark interface.

## What works
- Upload MP4/MOV/MKV/WEBM/M4V videos, or submit a public URL supported by `yt-dlp`.
- Creates up to 10 evenly spaced 30-second segments.
- Converts each segment to a 9:16 vertical MP4 and provides download links.

## Important limitations
This is **not yet AI highlight detection**. It splits at regular time intervals; it does not identify viral moments or add subtitles. YouTube links may fail because of platform restrictions, age/login checks, format changes, or hosting limits. Use only content you own or are authorized to process, and comply with the source platform's terms.

## Run locally
1. Install Python 3.11+ and FFmpeg (must include `ffmpeg` and `ffprobe` on PATH).
2. Unzip this project and open a terminal in the folder.
3. Run:
   ```bash
   pip install -r requirements.txt
   python app.py
   ```
4. Open `http://127.0.0.1:5000`.

## Deploy
The included `render.yaml` is a starting point for Render. Push this folder to a GitHub repository, then create a Render Blueprint from that repository. Free hosting has limited CPU, memory, request time and temporary storage; large video jobs may fail, and files on ephemeral disks may be lost on restart. For a public production service, use a worker/queue and persistent object storage, plus upload limits, abuse protection and user authentication.

## Next upgrades
- AI highlight detection using a transcription + ranking service.
- Word-level subtitles and editable caption styles.
- Job queue and progress updates.
- Persistent storage, quotas and rate limiting.
